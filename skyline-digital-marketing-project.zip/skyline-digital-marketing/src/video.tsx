import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate, Easing} from 'remotion';

const C = {bg:'#071426', hero:'#1473FF', accent:'#00E5FF', secondary:'#8BB8FF', text:'#FFFFFF', muted:'#A8C5E8', panel:'rgba(10,32,58,.78)'};
// Optional voiceover preview. Keep disabled by default so renders are silent unless explicitly enabled.
const ENABLE_PREVIEW_VOICEOVER = false; // Set true to hear public/voiceover.mp3 in Studio preview.
const PreviewAudio: React.FC = () => ENABLE_PREVIEW_VOICEOVER ? <Audio src={staticFile('voiceover.mp3')} volume={1}/> : null;
const FontFaces: React.FC = () => <style>{`@font-face{font-family:SkylineSans;src:url('${staticFile('fonts/NotoSans-Regular.ttf')}') format('truetype');font-weight:400}@font-face{font-family:SkylineSans;src:url('${staticFile('fonts/NotoSansBengali-Regular.ttf')}') format('truetype');font-weight:400}`}</style>;
const cues = [
 {s:.16,e:4.38,t:'আপনি কি Digital Marketing শিখে নিজের দক্ষতাকে নতুন উচ্চতায় নিয়ে যেতে চান?',en:'LEVEL UP YOUR SKILLS',kind:'hook'},
 {s:4.7,e:7.64,t:'তাহলে আপনার জন্য রয়েছে দারুণ একটি সুযোগ।',en:'A NEW OPPORTUNITY',kind:'opportunity'},
 {s:7.7,e:12.26,t:'Skyline IT Institute নিয়ে এসেছে সম্পূর্ণ free Digital Marketing course।',en:'100% FREE DIGITAL MARKETING COURSE',kind:'offer'},
 {s:12.88,e:14.76,t:'এই course আপনি শিখতে পারবেন Digital',en:'LEARN MULTIPLE SKILLS',kind:'hub'},
 {s:14.84,e:17,t:'Marketing, Social Media Marketing,',en:'SOCIAL MEDIA MARKETING',kind:'social'},
 {s:17.44,e:19.96,t:'Affiliate Marketing, CPA Marketing,',en:'AFFILIATE + CPA MARKETING',kind:'affiliate'},
 {s:20.4,e:23.04,t:'Pinterest Marketing, Adstera Marketing,',en:'PINTEREST + ADSTERA',kind:'pinterest'},
 {s:23.56,e:26.28,t:'Website Ad Campaign এবং Fiverr Marketplace',en:'WEBSITE ADS + FIVERR MARKETPLACE',kind:'marketplace'},
 {s:26.34,e:29.02,t:'সম্পর্কে গুরুত্বপূর্ণ বিষয়গুলো। সবচেয়ে',en:'PRACTICAL, USEFUL TOPICS',kind:'recap'},
 {s:29.06,e:31.62,t:'ভালো বিষয় হলো, কোন course fee ছাড়াই',en:'NO COURSE FEE',kind:'free'},
 {s:31.68,e:34.84,t:'শেখার সুযোগ রয়েছে। পাশাপাশি মোবাইল দিয়েও',en:'LEARN FROM YOUR MOBILE',kind:'mobile'},
 {s:34.88,e:37.4,t:'ক্লাসে অংশগ্রহণ করতে পারবেন। নিজের দক্ষতা',en:'JOIN CLASSES FROM ANYWHERE',kind:'class'},
 {s:37.44,e:41.86,t:'বাড়ান, নতুন বিষয় শিখুন এবং ভবিষ্যতের জন্য নিজেকে প্রস্তুত করুন।',en:'BUILD YOUR FUTURE',kind:'future'},
 {s:41.9,e:44.78,t:'তাহলে আর দেরি কেন? আজই শুরু হোক আপনার Digital Marketing',en:'START YOUR JOURNEY TODAY',kind:'start'},
 {s:44.9,e:47.98,t:'শেখার যাত্রা Skyline IT Institute সঙ্গে।',en:'SKYLINE IT INSTITUTE',kind:'brand'},
 {s:48.02,e:52.4,t:'বিস্তারিত জানতে আমাদের Facebook পেজে visit করুন এবং inbox লিখুন, “Yes”।',en:'VISIT FACEBOOK • INBOX “YES”',kind:'cta'}
];
const topics = [
 {name:'Social Media',sub:'Connect • Create • Grow',icon:'f',color:'#1877F2',start:14.84},
 {name:'Affiliate',sub:'Promote • Earn',icon:'↗',color:'#00E5FF',start:17.44},
 {name:'CPA Marketing',sub:'Action-based campaigns',icon:'CPA',color:'#8BB8FF',start:18.94},
 {name:'Pinterest',sub:'Visual discovery',icon:'P',color:'#E60023',start:20.4},
 {name:'Adstera',sub:'Ad network basics',icon:'A',color:'#FFB547',start:21.98},
 {name:'Website Ads',sub:'Campaign strategy',icon:'▣',color:'#00E5FF',start:23.56},
 {name:'Fiverr',sub:'Freelance marketplace',icon:'fi',color:'#1DBF73',start:25.32},
];
const clamp = (v:number,a=0,b=1)=>Math.max(a,Math.min(b,v));
const appear = (frame:number,start:number,duration=18)=>interpolate(frame,[start,start+duration],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)});
const slide = (frame:number,start:number,duration=20,dist=60)=>interpolate(frame,[start,start+duration],[dist,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.out(Easing.back(1.15))});

const BrandMark: React.FC<{frame:number;label?:string}> = ({frame,label='SKYLINE'}) => {
 const scale=interpolate(frame,[0,28],[.65,1],{extrapolateRight:'clamp',easing:Easing.out(Easing.back(1.3))});
 return <div style={{display:'flex',alignItems:'center',gap:18,transform:`scale(${scale})`}}><div style={{width:58,height:58,borderRadius:17,background:`linear-gradient(140deg,${C.accent},${C.hero})`,display:'grid',placeItems:'center',boxShadow:`0 0 34px ${C.accent}55`,fontSize:32,fontWeight:900,color:C.bg}}>S</div><div><div style={{fontSize:28,letterSpacing:4,fontWeight:900}}>{label}</div><div style={{fontSize:12,letterSpacing:3,color:C.secondary}}>IT INSTITUTE</div></div></div>
};
const TopicIcon: React.FC<{icon:string;color:string;frame:number}> = ({icon,color,frame}) => <div style={{width:86,height:86,borderRadius:24,background:`linear-gradient(145deg,${color},${color}99)`,display:'grid',placeItems:'center',fontSize:icon.length>2?22:42,fontWeight:900,color:'#fff',boxShadow:`0 18px 50px ${color}44, inset 0 1px 1px #ffffff88`,transform:`perspective(500px) rotateY(${Math.sin(frame/12)*10}deg) rotateX(${Math.cos(frame/15)*5}deg)`}}>{icon}</div>;

const FloatingCaption: React.FC<{text:string;en:string;frame:number;start:number}> = ({text,en,frame,start}) => {
 const local=frame-start; const op=appear(frame,start,16); const y=slide(frame,start,20,35); const float=Math.sin(local/10)*4;
 return <div style={{position:'absolute',top:58,left:140,right:140,textAlign:'center',opacity:op,transform:`translateY(${y+float}px)`}}>
  <div style={{display:'inline-block',padding:'17px 34px 20px',borderRadius:22,background:'linear-gradient(100deg,rgba(10,31,56,.94),rgba(14,54,93,.86))',border:`1px solid ${C.accent}66`,boxShadow:`0 16px 70px #0008,0 0 28px ${C.hero}33`,maxWidth:1500}}>
   <div style={{fontFamily:'SkylineSans, Noto Sans Bengali, sans-serif',fontWeight:800,fontSize:34,lineHeight:1.45,color:C.text,textShadow:`0 2px 16px ${C.accent}33`}}>{text}</div>
   <div style={{marginTop:5,fontSize:14,letterSpacing:4,fontWeight:800,color:C.accent}}>{en}</div>
  </div>
 </div>;
};

const Backdrop: React.FC<{frame:number}> = ({frame}) => {
 const pulse=0.45+Math.sin(frame/17)*.08;
 return <AbsoluteFill style={{background:`radial-gradient(ellipse at ${50+Math.sin(frame/70)*12}% ${45+Math.cos(frame/80)*10}%, #103b67 0%, ${C.bg} 56%, #030914 100%)`,overflow:'hidden'}}>
  <svg width="1920" height="1080" style={{position:'absolute',inset:0,opacity:.45}}>
   <defs><pattern id="dots" width="44" height="44" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1.3" fill={C.secondary} opacity=".45"/></pattern><linearGradient id="line" x1="0" x2="1"><stop stopColor={C.hero} stopOpacity="0"/><stop offset=".5" stopColor={C.accent} stopOpacity=".7"/><stop offset="1" stopColor={C.hero} stopOpacity="0"/></linearGradient></defs>
   <rect width="1920" height="1080" fill="url(#dots)"/>
   {Array.from({length:8},(_,i)=><path key={i} d={`M ${-80+i*260} 1080 Q ${300+i*140} ${420+Math.sin(frame/40+i)*60} ${180+i*250} 0`} fill="none" stroke="url(#line)" strokeWidth="1.5" opacity={pulse}/>) }
   {Array.from({length:24},(_,i)=>{const x=(i*197+frame*(i%3+1)*.7)%1920;const y=(i*83+Math.sin(frame/25+i)*50+1080)%1080;return <circle key={i} cx={x} cy={y} r={i%4===0?3:1.5} fill={i%3===0?C.accent:C.secondary} opacity={.35+((i%5)/10)}/>})}
  </svg>
  <div style={{position:'absolute',left:-150,top:240,width:440,height:440,border:`1px solid ${C.hero}55`,borderRadius:'50%',boxShadow:`0 0 80px ${C.hero}11`,transform:`rotate(${frame*.12}deg)`}}/>
  <div style={{position:'absolute',right:-130,bottom:-180,width:520,height:520,border:`1px solid ${C.accent}44`,borderRadius:'50%',boxShadow:`0 0 100px ${C.accent}11`,transform:`rotate(${-frame*.16}deg)`}}/>
 </AbsoluteFill>;
};

const BranchMap: React.FC<{frame:number;activeKind:string}> = ({frame,activeKind}) => {
 const visible=topics.filter(t=>frame/30>=t.start-.08);
 const hubX=960,hubY=520;
 const coords=[{x:400,y:390},{x:680,y:660},{x:890,y:760},{x:1120,y:760},{x:1330,y:650},{x:1510,y:470},{x:1510,y:720}];
 return <>
  <svg width="1920" height="1080" style={{position:'absolute',inset:0,overflow:'visible'}}>
   <defs><linearGradient id="branchGrad"><stop stopColor={C.hero}/><stop offset="1" stopColor={C.accent}/></linearGradient></defs>
   {visible.map((t,i)=>{const p=coords[i];const st=t.start*30;const prog=clamp((frame-st)/24);return <g key={t.name} opacity={prog}>
    <path d={`M ${hubX} ${hubY} C ${(hubX+p.x)/2} ${hubY-80}, ${(hubX+p.x)/2} ${p.y+40}, ${p.x} ${p.y}`} fill="none" stroke="url(#branchGrad)" strokeWidth="3" strokeDasharray="9 10" strokeDashoffset={Math.max(0,24-(frame-st))} opacity=".9"/>
    <circle cx={p.x} cy={p.y} r="7" fill={C.accent} opacity={.65+Math.sin(frame/6+i)*.2}/>
   </g>})}
  </svg>
  {visible.map((t,i)=>{const p=coords[i];const local=frame-t.start*30;const op=appear(frame,t.start*30,18);const y=slide(frame,t.start*30,22,55);const active=activeKind===t.name.toLowerCase().split(' ')[0] || (activeKind==='social'&&i===0) || (activeKind==='affiliate'&&(i===1||i===2)) || (activeKind==='pinterest'&&(i===3||i===4)) || (activeKind==='marketplace'&&(i===5||i===6));return <div key={t.name} style={{position:'absolute',left:p.x-145,top:p.y-70+y,width:290,opacity:op,transform:`scale(${active?1.08:.92})`,transition:'none'}}>
    <div style={{display:'flex',alignItems:'center',gap:15,background:active?'linear-gradient(120deg,rgba(14,70,117,.96),rgba(6,23,42,.95))':'rgba(5,20,37,.83)',border:`1px solid ${active?C.accent:C.secondary+'55'}`,borderRadius:22,padding:'16px 18px',boxShadow:active?`0 0 34px ${t.color}55,0 16px 45px #0008`:'0 15px 35px #0007'}}>
     <TopicIcon icon={t.icon} color={t.color} frame={frame+i*10}/><div style={{minWidth:0}}><div style={{fontSize:23,fontWeight:900,color:C.text}}>{t.name}</div><div style={{fontSize:13,color:C.muted,marginTop:5}}>{t.sub}</div></div>
    </div>
   </div>})}
  <div style={{position:'absolute',left:790,top:420,width:340,textAlign:'center',opacity:appear(frame,12.88*30,20)}}>
   <div style={{margin:'0 auto 18px',width:112,height:112,borderRadius:34,display:'grid',placeItems:'center',background:`linear-gradient(140deg,${C.hero},#07406b)`,border:`2px solid ${C.accent}`,boxShadow:`0 0 70px ${C.hero}66`,fontSize:44,fontWeight:900,transform:`perspective(500px) rotateY(${Math.sin(frame/20)*8}deg)`}}>DM</div>
   <div style={{fontSize:30,fontWeight:900,letterSpacing:2}}>DIGITAL MARKETING</div><div style={{color:C.accent,fontSize:14,letterSpacing:4,marginTop:8}}>SKILL HUB</div>
  </div>
 </>;
};

const HeroVisual: React.FC<{frame:number;kind:string}> = ({frame,kind}) => {
 const f=frame;
 if(['hub','social','affiliate','pinterest','marketplace','recap'].includes(kind)) return <BranchMap frame={f} activeKind={kind}/>;
 const localStart=kind==='hook'?0:kind==='opportunity'?4.7*30:kind==='offer'?7.7*30:kind==='free'?29.06*30:kind==='mobile'?31.68*30:kind==='class'?34.88*30:kind==='future'?37.44*30:kind==='start'?41.9*30:kind==='brand'?44.9*30:48.02*30;
 const op=appear(f,localStart,22); const pop=slide(f,localStart,24,70);
 if(kind==='hook') return <div style={{position:'absolute',left:230,right:230,top:360,height:390,display:'flex',alignItems:'center',justifyContent:'center',gap:50,opacity:op}}>
   <div style={{width:310,height:310,borderRadius:80,background:'linear-gradient(145deg,#1473FF,#062c57)',border:`2px solid ${C.accent}`,boxShadow:`0 0 100px ${C.hero}55`,display:'grid',placeItems:'center',fontSize:94,fontWeight:1000,transform:`perspective(700px) rotateY(${Math.sin(f/18)*12}deg) rotateX(${Math.cos(f/22)*5}deg) scale(${1+Math.sin(f/10)*.02})`}}>DM</div>
   <div style={{maxWidth:790,transform:`translateY(${pop}px)`}}><div style={{fontSize:22,letterSpacing:5,color:C.accent,fontWeight:800}}>YOUR NEXT SKILL STARTS HERE</div><div style={{fontSize:72,fontWeight:1000,lineHeight:1.06,marginTop:18}}>DIGITAL<br/><span style={{color:C.accent}}>MARKETING</span></div><div style={{fontSize:26,color:C.muted,marginTop:24}}>Learn • Build • Grow</div></div>
  </div>;
 if(kind==='opportunity'||kind==='offer') return <div style={{position:'absolute',left:0,right:0,top:360,textAlign:'center',opacity:op,transform:`translateY(${pop}px)`}}>
   <div style={{display:'inline-flex',alignItems:'center',gap:28,padding:'34px 48px',borderRadius:36,background:'linear-gradient(125deg,rgba(20,115,255,.26),rgba(0,229,255,.07))',border:`1px solid ${C.accent}88`,boxShadow:`0 0 80px ${C.hero}33`}}><div style={{fontSize:84,color:C.accent}}>✦</div><div style={{textAlign:'left'}}><div style={{fontSize:23,color:C.secondary,letterSpacing:4}}>A BIG OPPORTUNITY</div><div style={{fontSize:56,fontWeight:1000}}>{kind==='offer'?'FREE COURSE':'READY TO GROW?'}</div><div style={{fontSize:22,color:C.muted,marginTop:8}}>Professional skills • Real-world topics</div></div></div>
   {kind==='offer'&&<div style={{marginTop:25,fontSize:25,fontWeight:900,color:C.accent,letterSpacing:7}}>NO COURSE FEE</div>}
  </div>;
 if(kind==='free') return <div style={{position:'absolute',left:0,right:0,top:360,textAlign:'center',opacity:op,transform:`translateY(${pop}px)`}}><div style={{fontSize:120,fontWeight:1000,color:C.accent,textShadow:`0 0 45px ${C.accent}66`}}>৳ 0</div><div style={{fontSize:34,fontWeight:900,letterSpacing:5}}>LEARN WITHOUT COURSE FEES</div><div style={{margin:'28px auto',width:520,height:8,borderRadius:9,background:`linear-gradient(90deg,${C.hero},${C.accent})`,boxShadow:`0 0 30px ${C.accent}66`}}/></div>;
 if(kind==='mobile'||kind==='class') return <div style={{position:'absolute',left:0,right:0,top:340,display:'flex',justifyContent:'center',alignItems:'center',gap:100,opacity:op,transform:`translateY(${pop}px)`}}><div style={{width:235,height:390,border:'8px solid #d8e9ff',borderRadius:42,background:'linear-gradient(180deg,#123b64,#061425)',boxShadow:`0 0 70px ${C.hero}44`,padding:14,boxSizing:'border-box'}}><div style={{height:7,width:65,background:'#d8e9ff',borderRadius:8,margin:'0 auto 25px'}}/><div style={{height:100,borderRadius:18,background:`linear-gradient(135deg,${C.hero},${C.accent})`,display:'grid',placeItems:'center',fontSize:42,fontWeight:900}}>▶</div><div style={{marginTop:22,fontSize:17,fontWeight:800,textAlign:'center'}}>ONLINE CLASS</div><div style={{marginTop:18,display:'flex',gap:8,justifyContent:'center'}}>{[1,2,3].map(n=><div key={n} style={{width:38,height:38,borderRadius:12,background:'#1a5483'}}/>)}</div><div style={{margin:'22px auto',width:135,height:8,borderRadius:8,background:C.accent}}/></div><div style={{maxWidth:540}}><div style={{fontSize:20,color:C.accent,letterSpacing:5}}>LEARN ANYWHERE</div><div style={{fontSize:58,fontWeight:1000,lineHeight:1.1,marginTop:15}}>YOUR CLASSROOM.<br/><span style={{color:C.accent}}>YOUR MOBILE.</span></div><div style={{fontSize:23,color:C.muted,marginTop:25}}>Flexible learning, wherever you are.</div></div></div>;
 if(kind==='future'||kind==='start') return <div style={{position:'absolute',left:0,right:0,top:385,textAlign:'center',opacity:op,transform:`translateY(${pop}px)`}}><div style={{fontSize:23,color:C.accent,letterSpacing:6,fontWeight:900}}>{kind==='future'?'INVEST IN YOUR SKILLS':'YOUR JOURNEY STARTS NOW'}</div><div style={{fontSize:74,fontWeight:1000,marginTop:18,lineHeight:1.08}}>{kind==='future'?'BUILD A BETTER':'TAKE THE FIRST'}<br/><span style={{color:C.accent}}>{kind==='future'?'FUTURE':'STEP TODAY'}</span></div><div style={{display:'flex',justifyContent:'center',gap:14,marginTop:34}}>{['LEARN','PRACTICE','GROW'].map((x,i)=><div key={x} style={{padding:'14px 24px',borderRadius:15,border:`1px solid ${C.accent}77`,background:`${C.hero}22`,fontWeight:900,letterSpacing:2,transform:`translateY(${Math.sin(f/9+i)*5}px)`}}>{x}</div>)}</div></div>;
 if(kind==='brand'||kind==='cta') return <div style={{position:'absolute',left:0,right:0,top:330,display:'flex',flexDirection:'column',alignItems:'center',gap:35,opacity:op,transform:`translateY(${pop}px)`}}><BrandMark frame={f-localStart}/><div style={{fontSize:62,fontWeight:1000,textAlign:'center',lineHeight:1.08}}>SKYLINE IT INSTITUTE<br/><span style={{color:C.accent}}>{kind==='cta'?'MESSAGE “YES” TO START':'YOUR DIGITAL FUTURE'}</span></div>{kind==='cta'&&<div style={{display:'flex',alignItems:'center',gap:18,borderRadius:24,padding:'20px 38px',background:'linear-gradient(90deg,#1877F2,#0d5cba)',boxShadow:'0 0 65px #1877F255',fontSize:27,fontWeight:900}}><span style={{fontSize:38}}>f</span> VISIT FACEBOOK PAGE <span style={{color:'#fff',background:'#00b9f1',borderRadius:12,padding:'10px 18px'}}>INBOX “YES”</span></div>}</div>;
 return <div style={{position:'absolute',left:0,right:0,top:420,textAlign:'center',opacity:op}}><div style={{fontSize:70,fontWeight:1000}}>SKILLS FOR <span style={{color:C.accent}}>EVERYONE</span></div></div>;
};

export const Main: React.FC = () => {
 const frame=useCurrentFrame(); const {fps}=useVideoConfig(); const seconds=frame/fps;
 const cue=[...cues].reverse().find(c=>seconds>=c.s) || cues[0];
 const cueStart=Math.round(cue.s*fps);
 const showBranch=seconds>=12.88 && seconds<29.05;
 const sfx=[{at:4.7,file:'sfx/whoosh.wav'},{at:7.7,file:'sfx/impact.wav'},{at:14.84,file:'sfx/pop.wav'},{at:17.44,file:'sfx/pop.wav'},{at:18.94,file:'sfx/digital.wav'},{at:20.4,file:'sfx/whoosh.wav'},{at:21.98,file:'sfx/digital.wav'},{at:23.56,file:'sfx/pop.wav'},{at:25.32,file:'sfx/impact.wav'},{at:29.06,file:'sfx/shine.wav'},{at:31.68,file:'sfx/whoosh.wav'},{at:34.88,file:'sfx/pop.wav'},{at:42.48,file:'sfx/impact.wav'},{at:48.02,file:'sfx/shine.wav'},{at:50.2,file:'sfx/pop.wav'}];
 return <AbsoluteFill style={{background:C.bg,color:C.text,fontFamily:'SkylineSans, Noto Sans Bengali, Arial, sans-serif',overflow:'hidden'}}>
  <FontFaces />
  <Backdrop frame={frame}/>
  <PreviewAudio />
  <div style={{position:'absolute',top:28,left:55,zIndex:10,opacity:.9}}><BrandMark frame={frame%90}/></div>
  <div style={{position:'absolute',top:39,right:60,zIndex:10,display:'flex',alignItems:'center',gap:12}}><div style={{width:8,height:8,borderRadius:8,background:C.accent,boxShadow:`0 0 18px ${C.accent}`}}/><span style={{fontSize:13,letterSpacing:4,color:C.secondary,fontWeight:900}}>SKILL TIMELINE</span><span style={{fontSize:14,color:C.text,fontWeight:900}}>{String(Math.floor(seconds/60)).padStart(2,'0')}:{String(Math.floor(seconds%60)).padStart(2,'0')}</span></div>
  <FloatingCaption text={cue.t} en={cue.en} frame={frame} start={cueStart}/>
  <HeroVisual frame={frame} kind={cue.kind}/>
  <div style={{position:'absolute',bottom:36,left:90,right:90,zIndex:15}}>
   <div style={{display:'flex',justifyContent:'space-between',fontSize:12,letterSpacing:2,color:C.secondary,fontWeight:800,marginBottom:10}}><span>SKILL PATH</span><span>FREE • FLEXIBLE • PRACTICAL</span></div>
   <div style={{height:5,background:'#183553',borderRadius:8,overflow:'hidden'}}><div style={{height:'100%',width:`${Math.min(100,seconds/52.4*100)}%`,background:`linear-gradient(90deg,${C.hero},${C.accent})`,boxShadow:`0 0 20px ${C.accent}`,borderRadius:8}}/></div>
   <div style={{display:'flex',justifyContent:'space-between',marginTop:10,fontSize:11,letterSpacing:2,color:'#6f96bd'}}><span>DISCOVER</span><span>LEARN</span><span>BUILD SKILLS</span><span>START TODAY</span></div>
  </div>
  {sfx.map((x,i)=><Sequence key={`${x.at}-${i}`} from={Math.round(x.at*fps)} durationInFrames={Math.min(28,1594-Math.round(x.at*fps))}><Audio src={staticFile(x.file)} volume={.25}/></Sequence>)}
 </AbsoluteFill>;
};
