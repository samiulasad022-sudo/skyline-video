import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {Main} from './video';

const Root: React.FC = () => <Composition id="Main" component={Main} durationInFrames={1594} fps={30} width={1920} height={1080} />;
registerRoot(Root);
