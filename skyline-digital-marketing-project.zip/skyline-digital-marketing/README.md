# Skyline IT Institute — Digital Marketing Motion Graphics

Remotion composition: `Main` · 1920×1080 · 30fps · 53.13 seconds (voiceover file duration).

## Run

```bash
npm install
npm run start
```

## Render

```bash
npm run render
```

## Included
- Top-floating Bengali/English captions timed from the supplied voiceover transcript JSON.
- Electric Blue & Cyber Cyan palette.
- Branching skill-map animation that adds marketing topics in the order they are spoken.
- Layered moving particles, animated connection paths, glass-style cards, 3D-ish icon motion, timeline progress and multiple generated SFX.
- `public/voiceover.mp3` contains the supplied Bengali voiceover. To hear it in Studio preview, set `ENABLE_PREVIEW_VOICEOVER` to `true` in `src/video.tsx`; it is false by default so renders remain voiceover-muted until enabled.
- Brand mark is a designed text-based placeholder; replace with the official Skyline IT Institute logo if available.

This is an editable Remotion source project. Install dependencies before opening Studio.
- Includes local Noto Sans and Noto Sans Bengali font files under `public/fonts/` so typography does not depend on network access.
- To enable voiceover preview, change `ENABLE_PREVIEW_VOICEOVER` to `true` in `src/video.tsx`.
